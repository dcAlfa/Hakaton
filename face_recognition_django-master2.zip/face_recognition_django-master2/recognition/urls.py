from django.urls import path, include
from recognition import views


urlpatterns = [
    path('', views.index, name='index'),
    path('facecam_feed', views.facecam_feed, name='facecam_feed'),
    path('contact/', views.contact, name='contact'),
    path('jurnal/', views.jurnal, name='jurnal'),
    path('jurnalitems/', views.jurnalitems, name='jurnalitems'),
    path('media/', views.media, name='media'),
    path('news/', views.news, name='news'),
    ]