from imutils.video import VideoStream
from imutils.video import FPS
import cv2,os
import numpy as np
from datetime import datetime
import face_recognition

def learning(file_path='photos'):
	known_faces_names = []
	known_face_encoding = []
	people = os.listdir(file_path)
	for person in people:
		image = face_recognition.load_image_file(f'{file_path}/{person}')
		if face_recognition.face_encodings(image):
			known_face_encoding.append(face_recognition.face_encodings(image)[0])
			known_faces_names.append(person[:person.rfind('.')])

	return known_faces_names, known_face_encoding

known_faces_names, known_face_encoding = learning()
ismlar = {}
class FaceDetect(object):
	def __init__(self):
		self.vs = VideoStream(src=0).start()
		self.fps = FPS().start()

	def __del__(self):
		cv2.destroyAllWindows()

	def get_frame(self):
		frame = self.vs.read()
		frame = cv2.flip(frame, 1)

		small_frame = cv2.resize(frame, (0, 0), fx=0.5, fy=0.5)

		rgb_small_frame = small_frame[:, :, ::-1]

		face_locations = face_recognition.face_locations(rgb_small_frame)
		face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

		face_names = []
		for face_encoding in face_encodings:
			matches = face_recognition.compare_faces(known_face_encoding, face_encoding, tolerance=0.47)
			name = "noma'lum shaxs"
			face_distances = face_recognition.face_distance(known_face_encoding, face_encoding)
			best_match_index = np.argmin(face_distances)
			if matches[best_match_index]:
				name = known_faces_names[best_match_index]

			face_names.append(name)
			for (top, right, bottom, left), name in zip(face_locations, face_names):
				top *= 2
				right *= 2
				bottom *= 2
				left *= 2

				cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)
				cv2.rectangle(frame, (left, bottom - (right - left) // 8), (right, bottom), (0, 0, 255), cv2.FILLED)
				font = cv2.FONT_HERSHEY_DUPLEX
				cv2.putText(frame, name, (left + 6, bottom - 6), font, (right - left) / 350, (255, 255, 255), 1)

				current_time = datetime.now().strftime("%H:%M:%S")
				if name in ismlar:
					ismlar[name][0] += 1
				else:
					ismlar[name] = [1, current_time]
				if ismlar[name][0] == 10:
					ismlar[name] = [1, current_time]
					print(name, ismlar[name][1])
		self.fps.update()
		ret, jpeg = cv2.imencode('.jpg', frame)
		return jpeg.tobytes()
