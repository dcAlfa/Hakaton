# face_recognition_django
Face recognition and identification using opencv,videostream implemented in django


## To run locally

1.  **Python3** should be installed on the system.
2. install dependency: \
     `pip install django
3. clone the repository from github using
      `git clone repository_url`
4. move in your project folder and run the commands given below:\
     `python manage.py makemigrations`\
     `python manage.py migrate`\
     `python manage.py runserver`
